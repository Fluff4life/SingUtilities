  module.exports = (client, guild) => {
    console.log(`${client.user.username} had leaved ${guild.name}`);
}