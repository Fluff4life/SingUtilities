module.exports = (client, guild) => {
  console.log(`${client.user.username} has joined to ${guild.name}`);
}